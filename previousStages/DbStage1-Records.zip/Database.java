/* Controlling class for the database */
public class Database {
   
    public static void main(String[] args) 
    {
        // Run the testing function when assertions are enabled
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
        
        Database db = new Database();
        Record record1 = new Record(new String[]{"1", "Fido", "dog", "ab123"});
        record1.printRecord();
    }
    
    // Testing function for Database, run when assertions are enabled
    private static void test() 
    {
        
    }
}