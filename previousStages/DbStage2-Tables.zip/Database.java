/* Controlling class for the database */
class Database
{
   
    public static void main(String[] args) 
    {
        // Run the testing function when assertions are enabled
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
        
        Database db = new Database();
        Record record1 = new Record(new String[]{"1", "Fido", "dog", "ab123"});
        
        // Two test records for testing the table
        Record testRecord1 = new Record(new String[]{"1", "Fido", "dog", "ab123"});
        Record testRecord2 = new Record(new String[]{"2", "Wanda", "fish", "ef789"});
        Record testRecord3 = new Record(new String[]{"ab123", "Jo"});
        
        // Test table for testing the other functions
        //Table testTable = new Table(new String[]{"Id", "Name", "Kind", "Owner"});
    }
    
    // Testing function for Database, run when assertions are enabled
    private static void test() 
    {
        
    }
}