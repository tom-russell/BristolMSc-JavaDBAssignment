import java.util.*;

/* The Table class is a generic class for storing a single table in a database. The table is made 
 * of a List of records, where all records must have the same number of attributes.
 * Functions are supplied for adding, removing and selected records. */
class Table 
{
    // A List stores the table records, the first record holds the attribute names.
    private List<Record> records;
    
    // Main function for use only when testing Table by itself
    public static void main(String[] args) 
    {
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
    }
    
    // Initialise the table record list, adding the table attributes names as the first record
    Table(String[] attributeNames) 
    {
        records = new ArrayList<Record>();
        records.add(new Record(attributeNames));
    }
    
    // Insert the new record into the table if it has the same number of attributes as the table,
    // returning true. If invalid, return false.
    public Boolean insert(Record newRecord)
    {
        if (newRecord.getSize() == records.get(0).getSize()) {
            records.add(newRecord);
            System.out.println("Record added successfully.");
            return true;
        }
        else {
            System.out.println("Failed to add record. Record does not match table.");
            return false;
        }
    }
    
    // Remove the record from the table at the given index, return true if index is valid. Index 0 
    // is the attribute row so counts as invalid.
    public Boolean delete(int index)
    {
        if (index == 0) {
            System.out.println("Failed to delete record. Invalid table index.");
            return false;
        }
        
        try {
            records.remove(index);
            System.out.println("Record deleted successfully.");
            return true;
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Failed to delete record. Invalid table index.");
            return false;
        }
    }
    
    // Update the record from the table at the given index with the new record, return true if 
    // index is valid. Index 0 is the attribute row so counts as invalid.
    public Boolean update(int index, Record newRecord) 
    {
        if (index == 0) {
            System.out.println("Failed to update record. Invalid table index.");
            return false;
        }
        
        if (newRecord.getSize() == records.get(0).getSize()) {
            try {
                records.remove(index);
                records.add(index, newRecord);
                System.out.println("Record updated successfully.");
                return true;
            }
            catch (IndexOutOfBoundsException e) {
                System.out.println("Failed to update record. Invalid table index.");
                return false;
            }
        }
        else {
            System.out.println("Failed to update record. New record does not match table.");
            return false;
        }
    }
    
    // Selects the given table index, and prints the record. Returns true if index is valid. 
    // Index 0 is the attribute row, so counts as invalid.
    public Boolean select(int index) 
    {
        if (index == 0) {
            System.out.println("Select failed. Invalid table index specified.");
            return false;
        }
        
        try {
            int size = records.get(index).getSize();
            printSelected(index, size);
            return true;
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Select failed. Invalid table index specified.");
            return false;
        }
    }
    
    // Print out the record at the given index in a formatted table ( with attribute names)
    private void printSelected(int index, int size) 
    {
        Record record = records.get(index);
        int[] printWidth = setPrintWidth(index);
        
        printDivider(printWidth);
        printRow(0, printWidth);
        printDivider(printWidth);
        printRow(index, printWidth);
        printDivider(printWidth);
    }
    
    // For the table being printed set printWidth to equal the highest number of characters for 
    // each attribute.
    private int[] setPrintWidth(int selected) 
    {
        int[] printWidth = new int[records.get(0).getSize()];
        int[] indexes = {0, selected};
        
        for (int attr = 0; attr < records.get(0).getSize(); attr++) {
            for (int index : indexes) {
                int newLength = records.get(index).getElement(attr).length() + 1;
                if (newLength > printWidth[attr]) printWidth[attr] = newLength;
            }
        }
        
        return printWidth;
    }
    
    // Print the row at the given index, with space padding based on printWidth.
    private void printRow(int index, int[] printWidth) 
    {
        for(int attr = 0; attr < records.get(0).getSize(); attr++) {
            System.out.print("| ");
            System.out.print("" + records.get(index).getElement(attr));
            
            int spaces = printWidth[attr] - records.get(index).getElement(attr).length();
            for (int j = 0; j < spaces; j++) System.out.print(" ");
            
        }
        System.out.println("|");
    }
    
    // Print the table divider, correctly formatted based on printWidth.
    private void printDivider(int[] printWidth) 
    {
        String divider = "+";
        
        for(int attr = 0; attr < printWidth.length; attr++) {
            for (int i = 0; i < printWidth[attr]; i++) divider += "-";
            divider += "-+";
        }
        
        System.out.println("" + divider);
    }
    
    // Tests for the Record class, this function is only called when Record is run by itself
    private static void test() 
    {
        // Two test records for testing the table
        Record testRecord1 = new Record(new String[]{"1", "Fido", "dog", "ab123"});
        Record testRecord2 = new Record(new String[]{"2", "Wanda", "hippopotamus", "ef789"});
        Record testRecord3 = new Record(new String[]{"ab123", "Jo"});
        Record testRecord4 = new Record(new String[]{"2", "Jeremy", "Axolotl", "ef789"});
        
        // Test table for testing the other functions
        Table testTable = new Table(new String[]{"Id", "Name", "Kind", "Owner"});
        
        // Testing the insert function with valid and invalid input (wrong number of attributes)
        assert(testTable.insert(testRecord1) == true);
        assert(testTable.insert(testRecord2) == true);
        assert(testTable.insert(testRecord3) == false);
        
        // Testing the select function with valid and invalid array indexes
        assert(testTable.select(1) == true);
        assert(testTable.select(2) == true);
        assert(testTable.select(0) == false);
        assert(testTable.select(3) == false);
        
        // Test for setPrintWidth
        assert(Arrays.equals(testTable.setPrintWidth(1), new int[]{3, 5, 5, 6}));
        assert(Arrays.equals(testTable.setPrintWidth(2), new int[]{3, 6, 13, 6}));
        
        // Testing the update function with valid and invalid array indexes, then test the update
        // has occured correctly
        assert(testTable.update(2, testRecord4) == true);
        assert(testTable.update(3, testRecord4) == false);
        assert(testTable.update(0, testRecord4) == false);
        assert(testTable.records.get(2).getElement(1).equals(testRecord4.getElement(1)));
        assert(testTable.records.get(2).getElement(2).equals(testRecord4.getElement(2)));
        
        // Testing the delete function with valid and invalid array indexes
        assert(testTable.delete(2) == true);
        assert(testTable.delete(1) == true);
        assert(testTable.delete(0) == false);
        // Testing that records have been properly removed
        assert(testTable.select(1) == false);
        assert(testTable.select(2) == false);
    }
}