import java.util.*;
import java.io.*;
import java.lang.String;

/* The Table class is a generic class for storing a single table in a database. The table is made 
 * of a List of records, where all records must have the same number of attributes.
 * Functions are supplied for adding/removing/accessing records. */
class Table 
{
    // A List stores the table records, the first record in the list holds the attribute names.
    private List<Record> records;
    private String tableName;
    private int nextID;
    
    // Main function for use only when testing Table by itself
    public static void main(String[] args) 
    {
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
        try{System.in.read();} catch(Exception e) {}
    }
    
    // Initialise empty table with the input column headings
    Table(String name, String[] attributeNames) 
    {
        tableName = name;
        nextID = 0;
        records = new ArrayList<Record>();
        records.add(0, new Record(autoID(), attributeNames));
    }
    
    // Alternative constructor when loading a table from file.
    Table(String fileName, Boolean importData) {
        tableName = fileName;
        nextID = 0;
        records = new ArrayList<Record>();
        loadTable(fileName, importData);
    }
    
    // Used to determine if two records are the same
    public boolean equals(Table other)
    {
        if (this.records.size() != other.records.size()) return false;
        if (this.nextID != other.nextID) return false;
        for (int i = 0; i < this.records.size(); i++) {
            if (this.records.get(i).equals(other.records.get(i)) == false) return false;
        }
        return true;
    }
    
    // Return the name of the table as a string.
    public String getName() { return tableName; }
    
    // Returns the next record ID as a string and increment nextID
    private int autoID() 
    { 
        int newID = nextID; 
        nextID++; 
        return newID; 
    }
    
    // Insert the new record into the table if it has the correct number of attributes, returning
    // true, else return false. If this is the first record do not check for size.
    // If ID == -1, autogenerate new ID. Else use the given ID value.
    public Boolean insert(String[] inputStrings, int ID, Boolean noOut)
    {
        if (records.size() == 0 || inputStrings.length == records.get(0).getSize()) 
        {
            if (ID == -1) records.add(new Record(autoID(), inputStrings));
            else          records.add(new Record(ID, inputStrings));
            
            if (noOut == false) System.out.println("Record added successfully.");
            return true;
        }
        else {
            if (noOut == false) System.out.println("Failed to add record, does not match table.");
            return false;
        }
    }
    
    // Remove the record from the table at the given index, return true if index is valid. Index 0 
    // is the attribute row so is invalid.
    public Boolean delete(int index)
    {
        if (index == 0) {
            System.out.println("Failed to delete record. Invalid table index.");
            return false;
        }
        
        try {
            records.remove(index);
            System.out.println("Record deleted successfully.");
            return true;
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Failed to delete record. Invalid table index.");
            return false;
        }
    }
    
    // Update the record from the table at the given index with the new record, return true if 
    // index is valid. Index 0 is the attribute row so counts as invalid.
    // If ID == -1, autogenerate new ID. Else use the given ID value.
    public Boolean update(int index, String[] inputStrings) 
    {
        if (index == 0) {
            System.out.println("Failed to update record. Invalid table index.");
            return false;
        }
        
        if (inputStrings.length == records.get(0).getSize()) {
            try {
                int recordID = records.get(index).getID();
                records.remove(index);
                records.add(index, new Record(recordID, inputStrings));
                System.out.println("Record updated successfully.");
                return true;
            }
            catch (IndexOutOfBoundsException e) {
                System.out.println("Failed to update record. Invalid table index.");
                return false;
            }
        }
        else {
            System.out.println("Failed to update record. New record does not match table.");
            return false;
        }
    }
    
    // Print out the records at all the input indexes in a formatted table ( with attribute names).
    // If the indexes array just contains a 0, then print all table records. Return the number of 
    // records that were printed (excluding dividers & attribute names)
    public int select(int[] indexes) 
    {
        if (indexes.length == 1 && indexes[0] == 0) {
            indexes = new int[records.size() - 1];
            for (int i = 1; i < records.size(); i++) indexes[i - 1] = i;
        }
        
        int[] printWidth = setPrintWidth(indexes);
        int rowCount = 0;
        
        printDivider(printWidth, 0);
        printRow(0, printWidth);
        printDivider(printWidth, 1);
        for (int i = 0; i < indexes.length; i++) {
            printRow(indexes[i], printWidth);
            rowCount++;
        }
        printDivider(printWidth, 2);
        
        return rowCount;
    }
    
    // For the table being printed set printWidth to equal the highest number of characters for
    // each attribute (including the attribute names). This is for correct table formatting.
    // Also include the auto generated ID as a column
    private int[] setPrintWidth(int[] indexes) 
    {
        int numCols = records.get(0).getSize() + 1;
        int[] printWidth = new int[numCols];
        printWidth[0] = 3;
        
        for (int attr = 1; attr < numCols; attr++) {
            printWidth[attr] = records.get(0).getElement(attr - 1).length() + 1;
        }
        
        for (int index : indexes) {
            int newIDLength = String.valueOf(records.get(index).getID()).length() + 1;
            if (newIDLength > printWidth[0]) printWidth[0] = newIDLength;
            
            for (int attr = 1; attr < numCols; attr++) {
                int newLength = records.get(index).getElement(attr - 1).length() + 1;
                if (newLength > printWidth[attr]) printWidth[attr] = newLength;
            }
        }
        
        return printWidth;
    }
    
    // Print the row at the given index, with space padding based on printWidth.
    private void printRow(int index, int[] printWidth) 
    {
        String recordID;
        
        if (index == 0) recordID = "ID";
        else recordID = String.valueOf(records.get(index).getID());
        
        System.out.print(" \u2551 " + recordID);
        int spaces = printWidth[0] - recordID.length();
        for (int j = 0; j < spaces; j++) System.out.print(" ");
        
        for(int attr = 0; attr < records.get(0).getSize(); attr++) {
            System.out.print("\u2551 ");
            System.out.print("" + records.get(index).getElement(attr));
            
            spaces = printWidth[attr + 1] - records.get(index).getElement(attr).length();
            for (int j = 0; j < spaces; j++) System.out.print(" ");
            
        }
        System.out.println("\u2551");
    }
    
    // Print the table divider, correctly formatted based on printWidth with pos indicating where 
    // on the table the divider is.
    // pos = 0 (top table divider), pos = 1 (middle table divider), pos = 2 (bottom table divider)
    private void printDivider(int[] printWidth, int pos) 
    {
        // left/mid/right/horiz are the different unicode characters for box drawing
        String left, mid, right, horiz; 
        
        if      (pos == 0) { left = "\u2554"; mid = "\u2566"; right = "\u2557"; horiz = "\u2550"; }
        else if (pos == 1) { left = "\u2560"; mid = "\u256C"; right = "\u2563"; horiz = "\u2550"; }
        else               { left = "\u255A"; mid = "\u2569"; right = "\u255D"; horiz = "\u2550"; }
        String divider = " " + left;
        
        for(int attr = 0; attr < printWidth.length; attr++) {
            for (int i = 0; i < printWidth[attr]; i++) divider += horiz;
            divider += horiz + mid;
        }
        
        System.out.println(divider.substring(0, divider.length() - 1) + right);
    }
    
    // Save a table as CSV format to file. For each record in the table, create a string of all the
    // elements separated by commas, with a newline at the end and write to file.
    public Boolean saveTable()
    {
        String path = "tableFiles/" + tableName + ".tab";
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (int rec = 0; rec < records.size(); rec++) {
                String line = "" + records.get(rec).getID() + ",";
                
                for (int attr = 0; attr < records.get(0).getSize(); attr++) {
                    line += records.get(rec).getElement(attr) + ",";
                }
                
                line = line.substring(0, line.length() - 1);
                bw.write(line);
                bw.newLine();
            }
        }
        catch (IOException e) {
            System.out.println("Failed to save table!");
            return false;
        }
        
        return true;
    }
    
    // Load a csv file, convert each line from the file into a record and insert the record into
    // the table. If importData == true, the data is from an external source, with no ID column.
    private Boolean loadTable(String fileName, Boolean importData) 
    {
        int highestID;
        String path = "tableFiles/" + fileName;
        if (importData == true) path += ".csv";
        else                    path += ".tab";
        
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = "";
            int validLines = 0, invalidLines = 0;
            
            while ((line = br.readLine()) != null) {
                String[] lineSplit = line.split(",");
                
                // If importing CSV data, autogenerate ID. Else the first value is the ID
                int ID;
                if (importData == true) ID = -1;
                else {
                    ID = Integer.parseInt(lineSplit[0]);
                    if (ID >= nextID) nextID = ID + 1;
                    lineSplit = Arrays.copyOfRange(lineSplit, 1, lineSplit.length);
                }
                
                if (insert(lineSplit, ID, true) == true ) validLines++;
                else invalidLines++;
            }
            
            System.out.println("Entries loaded: "   + validLines +
                               "\nFailed entries: " + invalidLines);
            return true;
        }
        catch (IOException e) {
            System.out.println("Failed to load table!");
            return false;
        }
    }
    
    // Tests for the Record class, this function is only called when Record is run by itself
    private static void test() 
    {
        // Two test records for testing the table
        String[] recordStr1 = {"Fido", "dog", "ab123"};
        String[] recordStr2 = {"Wanda", "hippopotamus", "ef789"};
        String[] recordStr3 = {"Jeremy", "Axolotl", "ef789"};
        String[] recordStr4 = {"ab123", "Jo"};
        String[] recordStr5 = {"ef789", "Jeff"};
        
        // Test table for testing the other functions
        Table testTable = new Table("Pets", new String[]{"Name", "Kind", "Owner"});
        
        // Testing the insert function with valid and invalid input (wrong number of attributes)
        assert(testTable.insert(recordStr1, -1, false) == true);
        assert(testTable.insert(recordStr2, -1, false) == true);
        assert(testTable.insert(recordStr4, -1, false) == false);
        
        // Testing the select function with different index selections (int[]{0} is select all)
        assert(testTable.select(new int[]{1}) == 1);
        assert(testTable.select(new int[]{2}) == 1);
        assert(testTable.select(new int[]{1, 2}) == 2);
        assert(testTable.select(new int[]{2, 1}) == 2);
        assert(testTable.select(new int[]{0}) == 2);
        
        // Test for setPrintWidth
        assert(Arrays.equals(testTable.setPrintWidth(new int[]{1}), new int[]{3, 5, 5, 6}));
        assert(Arrays.equals(testTable.setPrintWidth(new int[]{2}), new int[]{3, 6, 13, 6}));
        assert(Arrays.equals(testTable.setPrintWidth(new int[]{1, 2}), new int[]{3, 6, 13, 6}));
        assert(Arrays.equals(testTable.setPrintWidth(new int[]{2, 1}), new int[]{3, 6, 13, 6}));
        
        // Testing the update function with valid and invalid array indexes, then test the update
        // has occured correctly (same ID and elements are equal to the new string values)
        int prevID = testTable.records.get(2).getID();
        assert(testTable.update(2, recordStr3) == true);
        assert(testTable.update(3, recordStr3) == false);
        assert(testTable.update(0, recordStr3) == false);
        assert(testTable.update(2, recordStr4) == false);
        
        int newID = testTable.records.get(2).getID();
        assert(prevID == newID);
        
        assert(testTable.records.get(2).getElement(0).equals(recordStr3[0]));
        assert(testTable.records.get(2).getElement(1).equals(recordStr3[1]));
        assert(testTable.records.get(2).getElement(2).equals(recordStr3[2]));
        
        // Testing the delete function with valid and invalid array indexes
        assert(testTable.delete(2) == true);
        assert(testTable.delete(1) == true);
        assert(testTable.delete(0) == false);
        // Testing that the records have been properly removed
        assert(testTable.records.size() == 1);
        
        // Testing the save and load functionality
        Table testTable2 = new Table("test", new String[]{"OwnerId", "Name"});
        Table testTable3 = new Table("test", new String[]{"OwnerId", "Name"});
        testTable2.insert(recordStr4, -1, false);
        testTable2.insert(recordStr5, -1, false);
        assert(testTable2.equals(testTable3) == false);
        assert(testTable2.saveTable() == true);
        testTable3 = new Table("test", false);
        assert(testTable2.equals(testTable3) == true);
        // Clean-up test file at the end
        try {
            File f1 = new File("tableFiles/test.csv");
            File f2 = new File("tableFiles/test.tab");
            f1.delete();
            f2.delete();
            
        }
        catch (SecurityException e) {
            System.out.println("Error deleting test file, SecurityException.");
        }
    }
}