import java.util.*;

/* The Record class is a generic class for storing a single row from a single database table. The
 * record data is private but can be accessed through the supplied functions. */ 
class Record 
{
    private int ID;
    private List<String> elements;
    
    // Main function for use only when testing Record by itself.
    public static void main(String[] args) 
    {
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
    }
    
    // Populate the List object with the inputs strings.
    Record(int newID, String[] inputs) 
    {
        ID = newID;
        elements = new ArrayList<String>();
        
        for (int i = 0; i < inputs.length; i++) {
            elements.add(inputs[i]);
        }
    }
    
    // Used to determine if two records are the same
    public boolean equals(Record other)
    {
        if (this.getSize() != other.getSize()) return false;
        else if (this.ID != other.ID) return false;
        
        for (int i = 0; i < this.getSize(); i++) {
            if (this.getElement(i).equals(other.getElement(i)) == false) return false;
        }
        
        return true;
    }
    
    //Retrieve an the record ID as an integer
    public int getID() 
    {
        return ID;
    }
    
    // Retrieve an individual element from the record, at given index i.
    public String getElement(int colIndex) 
    {
        try {
            return elements.get(colIndex);
        }
        catch (IndexOutOfBoundsException e) {
            System.out.println("Invalid column index specified.");
            return "\0";
        }
    }
    
    // Return the size of the record as an integer (number of elements/columns).
    public int getSize() 
    {
        return elements.size();
    }
    
    // Tests for the Record class, this function is only called when Record is run by itself.
    private static void test() 
    {
        // Two test records for testing the other functions
        Record testRecord1 = new Record(0, new String[]{"1", "Fido", "dog", "ab123"});
        Record testRecord2 = new Record(1, new String[]{"ab123", "Jo"});
        Record testRecord3 = new Record(0, new String[]{"1", "Fido", "dog", "ab123"});
        
        // Test the equals function
        assert(testRecord1.equals(testRecord3) == true);
        assert(testRecord3.equals(testRecord1) == true);
        assert(testRecord1.equals(testRecord2) == false);
        assert(testRecord2.equals(testRecord3) == false);
        
        // Test the getElement() function retrieves the correct string
        assert(testRecord1.getElement(0) == "1");
        assert(testRecord1.getElement(1) == "Fido");
        assert(testRecord1.getElement(2) == "dog");
        assert(testRecord1.getElement(3) == "ab123");
        assert(testRecord2.getElement(0) == "ab123");
        assert(testRecord2.getElement(1) == "Jo");
        
        // Test invalid inputs for getElement() 
        assert(testRecord1.getElement(-1) == "\0");
        assert(testRecord1.getElement(4) == "\0");
        assert(testRecord2.getElement(-1) == "\0");
        assert(testRecord2.getElement(2) == "\0");
        
        // Test the getSize() function
        assert(testRecord1.getSize() == 4);
        assert(testRecord2.getSize() == 2);
    }
}