/* Controlling class for the database program */
class Controller
{
   
    public static void main(String[] args) 
    {
        // Run the testing function when assertions are enabled
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
        
        Controller program = new Controller();
        program.run();
    }
    
    public void run() 
    {
        // Load table from file and print out all the records
        Table electionData = new Table("elections-2014");
        electionData.select(new int[]{0});
    }
    
    // Testing function for Database, run when assertions are enabled
    private static void test() 
    {
        
    }
}