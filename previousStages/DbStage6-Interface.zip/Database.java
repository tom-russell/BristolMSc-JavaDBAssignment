import java.util.*;
import java.io.*;

/* The Database class is a generic class for storing a database. The database holds a collection of
 * tables. */
class Database 
{
    private String name;
    private List<Table> tables;
    
    public static void main(String[] args)
    {
        // Run the testing function when assertions are enabled
        boolean testing = false;
        assert(testing = true);
        if (testing) {
            test();
        }
    }
    
    Database(String name)
    {
        this.name = name;
        tables = new ArrayList<Table>();
        
        loadDbTables();
    }
    
    // Set currentTable to the correct table from Tables using the given table name
    private Table findTable(String tableName)
    {
        for (Table table : tables)
        {
            if (table.getName().equals(tableName))
            {
                return table;
            }
        }
        return null;
    }
    
    // Load all database tables from this database directory
    private void loadDbTables()
    {
        File DbFolder = new File("databases/" + name);
        File[] tableFiles = DbFolder.listFiles();
        
        for (File file : tableFiles) 
        {
            String tableName = file.getName();
            FileIO fLoad = new FileIO(file, true);
            
            int pos = tableName.lastIndexOf(".");
            tableName = tableName.substring(0, pos);
            Table table = new Table(tableName, fLoad.getNext(), true);
            
            String[] next;
            int highestId, validLines;
            highestId = validLines = 0;
            
            while ((next = fLoad.getNext()) != null)
            {
                int thisId = Integer.parseInt(next[0]);
                if (thisId > highestId) highestId = thisId;
                
                if (table.insert(next, true) == true) validLines++;
            }
            
            table.setNextId(highestId + 1); 
            tables.add(table);
            System.out.print("Table loaded: " + tableName);
            System.out.println("\t(" + validLines + " Entries)");
        }
        
        if (tableFiles.length == 0) System.out.println("Database is empty, no tables to load!");
    }
    
    // Save all database tables from this database directory
    public void saveDbTables()
    {
        for (Table table : tables) 
        {
            String filePath = "databases/" + name + "/" + table.getName() + ".csv";
            File file = new File(filePath);
            FileIO fSave = new FileIO(file, false);
            
            for (int i = 0; i < table.getSize(); i++)
            {
                String[] record = table.getRecord(i);
                fSave.saveLineToFile(record);
            }

            System.out.println("Table saved: " + table.getName());
        }
    }
    
    // For the given input table name print out a formatted table of all records
    public List<String[]> getTableRecords(String tableName)
    {
        Table table = findTable(tableName);
        if (table == null) return null;
        
        List<String[]> printData = new ArrayList<String[]>();
        for (int i = 0; i < table.getSize(); i++)
        {
            printData.add(table.select(i));
        }
        return printData;
    }
    
    public String[] getTableList()
    {
        String[] nameList = new String[tables.size()];
        
        for (int i = 0; i < tables.size(); i++)
        {
            nameList[i] = tables.get(i).getName();
        }
        return nameList;
    }
    
    public Boolean tableExists(String name)
    {
        String[] tableList = getTableList();
        
        for (String table : tableList)
        {
            if (table.equals(name)) return true;
        }
        return false;
    }
    
    // Testing function for Database, run when assertions are enabled
    private static void test() 
    {
        
    }
}